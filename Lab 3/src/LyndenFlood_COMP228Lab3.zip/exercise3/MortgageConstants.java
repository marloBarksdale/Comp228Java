package exercise3;

public interface MortgageConstants {
    String BANK_NAME = "CityToronto Bank";
    double MAX_MORTGAGE_AMOUNT = 300000;
    int SHORT_TERM = 1;
    int MEDIUM_TERM = 3;
    int LONG_TERM = 5;
}
