package exercise2;

public class FullTimeGameTester extends GameTester {


    public FullTimeGameTester() {
        this.name = "Full Time";
        this.fullTime = true;
        this.salary = 3000;
    }

    @Override
    public void calculateSalary() {

    }
}
